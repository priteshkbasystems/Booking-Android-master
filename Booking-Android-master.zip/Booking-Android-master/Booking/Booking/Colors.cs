﻿












using Xamarin.Forms;

namespace Booking
{
   public static class ExportedColors {

      public static readonly Color AccentColor = Color.FromRgba(127, 0, 0, 255); 
      public static readonly string AccentColorStr = "#7F0000"; 

      public static readonly Color InverseTextColor = Color.FromRgba(255, 255, 255, 255); 
      public static readonly string InverseTextColorStr = "White"; 

   }
}
