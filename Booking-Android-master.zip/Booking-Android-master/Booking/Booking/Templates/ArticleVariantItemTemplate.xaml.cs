﻿using System;
using System.Collections.Generic;

using Xamarin.Forms;

namespace Booking.Templates
{
	public partial class ArticleVariantItemTemplate : ContentView
	{
		public ArticleVariantItemTemplate ()
		{
			InitializeComponent ();
		}
	}
}

