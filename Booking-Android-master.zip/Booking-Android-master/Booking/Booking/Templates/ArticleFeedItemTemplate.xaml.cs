﻿using System;
using System.Collections.Generic;
using Xamarin.Forms;

namespace Booking.Templates
{
	public partial class ArticleFeedItemTemplate : ContentView
	{
		public ArticleFeedItemTemplate ()
		{
			InitializeComponent ();
		}
	}
}

