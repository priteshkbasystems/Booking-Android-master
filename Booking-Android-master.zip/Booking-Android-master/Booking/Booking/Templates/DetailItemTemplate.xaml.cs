﻿using System;
using System.Collections.Generic;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;
namespace Booking.Templates
{
	public partial class DetailItemTemplate : ContentView
	{
		public DetailItemTemplate()
		{
			InitializeComponent ();
		}
	}
}
