﻿using System;
using System.Collections.Generic;
using Xamarin.Forms;

namespace Booking.Templates
{
	public partial class CommentItemTemplate : ContentView
	{
		public CommentItemTemplate ()
		{
			InitializeComponent ();
		}
	}
}

